from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from typing import Optional, List
from json_service import json_operations, xml_operations, special_formats

app = FastAPI()

@app.get("/json/parse")
async def parse_json(json_string: str):
    """Parses a JSON string into a JSON object."""
    try:
        return json_operations.parse_json(json_string)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/json/stringify")
async def stringify_json(data: str):
    """Serializes a JSON object into a JSON string."""
    try:
        return json_operations.stringify_json(data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/json/convert/xml")
async def convert_json_to_xml(json_data: dict):
    """Converts JSON data to XML format."""
    try:
        return xml_operations.convert_json_to_xml(json_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/json/convert/json")
async def convert_xml_to_json(xml_data: str):
    """Converts XML data to JSON format."""
    try:
        return xml_operations.convert_xml_to_json(xml_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/json/cdl")
async def handle_cdl(cdl_string: str):
    """Handles CDL (Character Delimited Lines) format."""
    try:
        return special_formats.handle_cdl(cdl_string)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/json/cookie")
async def handle_cookie(cookie_string: str):
    """Handles Cookie format."""
    try:
        return special_formats.handle_cookie(cookie_string)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/json/http")
async def handle_http_headers(http_header_string: str):
    """Handles HTTP header format."""
    try:
        return special_formats.handle_http_headers(http_header_string)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
