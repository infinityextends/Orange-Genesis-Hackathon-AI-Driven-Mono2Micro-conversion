import json
import xmltodict

def convert_json_to_xml(json_data: dict):
    """Converts JSON data to XML format."""
    return xmltodict.unparse({'root': json_data})  # Wrap in a root element

def convert_xml_to_json(xml_data: str):
    """Converts XML data to JSON format."""
    return json.dumps(xmltodict.parse(xml_data))
