from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from typing import Optional, Dict, Any

from src.config import json_config, xml_config, parser_config

app = FastAPI()

# Placeholder for configurations (In a real application, this would likely be stored in a database or config file)
parser_configurations = {}

# API Endpoints
@app.post("/parser/json/configure")
async def configure_json_parser(config: json_config.JSONParserConfiguration):
    """Configures the JSON parser with custom settings."""
    try:
        json_config.configure_json_parser(config)
        return {"message": "JSON parser configured successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/parser/xml/configure")
async def configure_xml_parser(config: xml_config.XMLParserConfiguration):
    """Configures the XML parser with custom settings."""
    try:
        xml_config.configure_xml_parser(config)
        return {"message": "XML parser configured successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/parser/registerConverter")
async def register_converter(converter_name: str, converter_logic: Dict):
    """Registers a new custom converter."""
    try:
        parser_config.register_converter(converter_name, converter_logic)
        return {"message": f"Converter '{converter_name}' registered successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/parser/getConfiguration/{config_name}")
async def get_configuration(config_name: str):
    """Retrieves a parser configuration by name."""
    config = parser_config.get_configuration(config_name)
    if config:
        return config
    else:
        raise HTTPException(status_code=404, detail="Configuration not found")
