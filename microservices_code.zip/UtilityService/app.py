from fastapi import FastAPI, HTTPException
from utility_service.string_builder import StringBuilderWriter
from utility_service.json_exception import JSONException
from utility_service.json_pointer_exception import JSONPointerException
from utility_service.json_string import JSONString
from utility_service.property import Property

app = FastAPI()

# Placeholder for centralizing functionalities for other services
def centralize_functionality(data: dict):
    """
    Placeholder function to centralize functionalities.
    This is where logic for other services would be centralized
    """
    # Dummy example:
    if not isinstance(data, dict):
        raise ValueError("Input must be a dictionary.")
    return {"processed_data": data}

# Placeholder function for error handling
def handle_error(error: Exception):
    """
    Placeholder function to handle errors.
    """
    print(f"Error occurred: {error}")
    raise HTTPException(status_code=500, detail=str(error))  # Example using HTTPException

@app.get("/health")
async def health_check():
    """
    Health check endpoint.
    """
    return {"status": "ok"}

@app.post("/centralize")
async def centralize(data: dict):
    """
    Example endpoint utilizing centralize_functionality with error handling
    """
    try:
        result = centralize_functionality(data)
        return result
    except Exception as e:
        handle_error(e)

# Example endpoints to test the utility functions, though these are really just for demonstration as they are classes
@app.get("/string_builder")
async def string_builder_example():
    """
    Example endpoint using StringBuilderWriter.
    """
    builder = StringBuilderWriter()
    builder.write("Hello, ")
    builder.write("World!")
    return {"message": builder.to_string()}

@app.get("/json_exception")
async def json_exception_example():
    """
    Example endpoint for JSONException.
    """
    try:
        raise JSONException("A JSON exception occurred.")
    except JSONException as e:
        return {"error": str(e)}

@app.get("/json_pointer_exception")
async def json_pointer_exception_example():
    """
    Example endpoint for JSONPointerException.
    """
    try:
        raise JSONPointerException("A JSON pointer exception occurred.")
    except JSONPointerException as e:
        return {"error": str(e)}

@app.get("/json_string")
async def json_string_example():
    """
    Example endpoint for JSONString.
    """
    json_string = JSONString("example")
    return {"value": json_string.to_string()}

@app.get("/property")
async def property_example():
    """
    Example endpoint for Property.
    """
    prop = Property("name", "value")
    return {"name": prop.name, "value": prop.value}
