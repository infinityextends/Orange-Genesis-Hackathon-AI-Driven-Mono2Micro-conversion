class JSONException(Exception):
    """
    Custom JSON Exception.
    """
    pass
