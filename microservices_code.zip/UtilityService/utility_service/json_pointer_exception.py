class JSONPointerException(Exception):
    """
    Custom JSON Pointer Exception.
    """
    pass
