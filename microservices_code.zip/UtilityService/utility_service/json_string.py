class JSONString:
    """
    Represents a JSON string.
    """
    def __init__(self, value: str):
        self.value = value

    def to_string(self) -> str:
        return f'"{self.value}"'
