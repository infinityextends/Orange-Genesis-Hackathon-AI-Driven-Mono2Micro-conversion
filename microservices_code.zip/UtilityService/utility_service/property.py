class Property:
    """
    Represents a simple property.
    """
    def __init__(self, name: str, value: str):
        self.name = name
        self.value = value
