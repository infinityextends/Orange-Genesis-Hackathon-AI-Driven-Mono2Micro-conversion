class StringBuilderWriter:
    """
    Mimicking Java's StringBuilderWriter functionality.
    """
    def __init__(self):
        self.buffer = ""

    def write(self, s: str):
        self.buffer += s

    def to_string(self) -> str:
        return self.buffer
